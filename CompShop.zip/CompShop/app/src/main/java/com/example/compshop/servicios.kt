package com.example.compshop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class servicios : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_servicios)
    }
}